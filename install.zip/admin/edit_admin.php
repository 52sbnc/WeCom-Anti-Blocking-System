<?php
session_start();
require_once '../config.php';
require_once '../functions.php'; 

// 未登录则跳转
if (!isset($_SESSION['admin_login']) || $_SESSION['admin_login'] !== true) {
    header('Location: login.php');
    exit;
}

$success_msg = '';
$error_msg = '';

// 处理密码修改
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old_pwd = trim($_POST['old_pwd']);
    $new_pwd = trim($_POST['new_pwd']);
    $confirm_pwd = trim($_POST['confirm_pwd']);
    
    // 验证
    if (empty($old_pwd) || empty($new_pwd) || empty($confirm_pwd)) {
        $error_msg = '请填写所有密码字段';
    } elseif ($new_pwd !== $confirm_pwd) {
        $error_msg = '两次输入的新密码不一致';
    } elseif (strlen($new_pwd) < 6) {
        $error_msg = '新密码长度不能少于6位';
    } else {
        try {
            // 验证原密码
            $stmt = $pdo->prepare("SELECT * FROM admin_users WHERE id = ? AND password = ?");
            $stmt->execute([$_SESSION['admin_id'], $old_pwd]);
            $admin = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$admin) {
                $error_msg = '原密码错误';
            } else {
                // 修改密码
                $stmt = $pdo->prepare("UPDATE admin_users SET password = ? WHERE id = ?");
                $stmt->execute([$new_pwd, $_SESSION['admin_id']]);
                $success_msg = '密码修改成功，请重新登录';
                // 清除session
                unset($_SESSION['admin_login'], $_SESSION['admin_id'], $_SESSION['admin_name']);
            }
        } catch (PDOException $e) {
            $error_msg = '修改失败：' . $e->getMessage();
        }
    }
}

// 已退出则跳转登录
if (!isset($_SESSION['admin_login'])) {
    header('Refresh: 3; URL=login.php');
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>修改密码 - 后台</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="header">
        <h2>投诉系统后台</h2>
        <div class="user-info">
            <?php if (isset($_SESSION['admin_name'])): ?>
                欢迎，<?php echo $_SESSION['admin_name']; ?> | 
                <a href="index.php">返回首页</a> | 
                <a href="login.php?action=logout" onclick="return confirm('确定退出？')">退出登录</a>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="container">
        <div class="card" style="max-width:500px;margin:0 auto;">
            <div class="card-header">
                <h3>修改管理员密码</h3>
            </div>
            
            <?php if ($success_msg): ?>
                <div class="alert alert-success"><?php echo $success_msg; ?></div>
                <p>3秒后自动跳转到登录页...</p>
            <?php else: ?>
                <?php if ($error_msg): ?>
                    <div class="alert alert-danger"><?php echo $error_msg; ?></div>
                <?php endif; ?>
                
                <form method="post">
                    <div class="form-group">
                        <label>原密码</label>
                        <input type="password" name="old_pwd" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>新密码</label>
                        <input type="password" name="new_pwd" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>确认新密码</label>
                        <input type="password" name="confirm_pwd" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-success">保存新密码</button>
                    <a href="index.php" class="btn btn-outline" style="margin-left:10px;">取消</a>
                </form>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>