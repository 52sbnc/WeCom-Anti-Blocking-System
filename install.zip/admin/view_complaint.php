<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

// 未登录则跳转
if (!isset($_SESSION['admin_login']) || $_SESSION['admin_login'] !== true) {
    die('未登录');
}

// 获取投诉ID
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id <= 0) {
    die('无效的投诉ID');
}

// 获取投诉详情
try {
    $stmt = $pdo->prepare("
        SELECT cr.*, cl.wechat_key, cl.email 
        FROM complaint_records cr
        LEFT JOIN complaint_links cl ON cr.link_id = cl.id
        WHERE cr.id = ?
    ");
    $stmt->execute([$id]);
    $complaint = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$complaint) {
        die('投诉记录不存在');
    }
    
    // 处理图片（修复URL路径：去掉/api前缀）
    $images = [];
    if ($complaint['images']) {
        $image_list = explode(',', $complaint['images']);
        foreach ($image_list as $img) {
            // 核心修复：拼接正确的图片URL（根目录/uploads）
            $images[] = 'http://' . $_SERVER['HTTP_HOST'] . '/uploads/' . basename($img);
        }
    }
} catch (PDOException $e) {
    die('获取详情失败：' . $e->getMessage());
}
?>
<h3 style="margin-bottom:20px;border-bottom:1px solid #eee;padding-bottom:10px;">投诉详情 #<?php echo $complaint['id']; ?></h3>
<table class="table" style="font-size:14px;">
    <tr>
        <th width="150px">投诉ID</th>
        <td><?php echo $complaint['id']; ?></td>
    </tr>
    <tr>
        <th>关联链接ID</th>
        <td><?php echo $complaint['link_id']; ?></td>
    </tr>
    <tr>
        <th>投诉类型</th>
        <td><?php echo $complaint['type']; ?></td>
    </tr>
    <tr>
        <th>投诉内容</th>
        <td><?php echo nl2br(htmlspecialchars($complaint['content'])); ?></td>
    </tr>
    <tr>
        <th>联系方式</th>
        <td><?php echo $complaint['contact'] ?: '无'; ?></td>
    </tr>
    <tr>
        <th>提交IP</th>
        <td><?php echo $complaint['ip']; ?></td>
    </tr>
    <tr>
        <th>用户代理</th>
        <td><?php echo htmlspecialchars($complaint['user_agent'] ?: '无'); ?></td>
    </tr>
    <tr>
        <th>提交时间</th>
        <td><?php echo $complaint['submit_time']; ?></td>
    </tr>
    <tr>
        <th>关联微信Key</th>
        <td><?php echo $complaint['wechat_key'] ?: '未设置'; ?></td>
    </tr>
    <tr>
        <th>关联收件邮箱</th>
        <td><?php echo $complaint['email'] ?: '未设置'; ?></td>
    </tr>
    <?php if (!empty($images)): ?>
    <tr>
        <th>图片证据</th>
        <td>
            <?php foreach ($images as $img): ?>
                <img src="<?php echo $img; ?>" style="width:100px;height:100px;margin:5px;cursor:pointer;" onclick="previewImage('<?php echo $img; ?>')">
            <?php endforeach; ?>
        </td>
    </tr>
    <?php endif; ?>
</table>