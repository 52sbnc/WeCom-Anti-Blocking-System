// 确认删除
function confirmDelete(url) {
    if (confirm('确定要删除/停用吗？')) {
        window.location.href = url;
    }
}

// 筛选投诉记录
function filterComplaints() {
    var linkId = document.getElementById('link_id').value;
    window.location.href = 'complaint_list.php?link_id=' + linkId;
}

// 图片预览
function previewImage(url) {
    if (!url) return;
    var img = new Image();
    img.src = url;
    img.style.maxWidth = '80%';
    img.style.maxHeight = '80%';
    
    var dialog = document.createElement('div');
    dialog.style.position = 'fixed';
    dialog.style.top = '0';
    dialog.style.left = '0';
    dialog.style.width = '100%';
    dialog.style.height = '100%';
    dialog.style.background = 'rgba(0,0,0,0.8)';
    dialog.style.display = 'flex';
    dialog.style.justifyContent = 'center';
    dialog.style.alignItems = 'center';
    dialog.style.zIndex = '9999';
    dialog.onclick = function() {
        document.body.removeChild(dialog);
    };
    
    dialog.appendChild(img);
    document.body.appendChild(dialog);
}