$(window).scroll(function() {
    scollNavigation();
});

$(document).ready(function(){
    $(".navigation-icon").click(function(){
        $(".navigation-container-menu").slideToggle();
    });
});


function scollNavigation() {
    if (document.body.clientWidth > 767) {
        if ($(document).scrollTop() <= 30){
            $(".wechat-service").hide();
        } else {
            $(".wechat-service").show();
        }
    } else {
        $(".wechat-service").show();
    }
}

function openWeb(link) {
    var paramas = localStorage.getItem("paramas") || "";
    if (paramas == "") {
        window.open(link);
    } else {
        if(link.indexOf("?") != -1){
            window.open(link+"&"+paramas);
        } else {
            window.open(link+"?"+paramas);
        }
    }
}


function showService() {
    $('#showService').modal('toggle');
}