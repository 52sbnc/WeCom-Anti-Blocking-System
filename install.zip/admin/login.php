<?php
session_start();
require_once '../config.php';
require_once '../functions.php'; 

// 已登录则跳转
if (isset($_SESSION['admin_login']) && $_SESSION['admin_login'] === true) {
    header('Location: index.php');
    exit;
}

$error_msg = '';

// 处理登录
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    
    try {
        $stmt = $pdo->prepare("SELECT * FROM admin_users WHERE username = ? AND password = ?");
        $stmt->execute([$username, $password]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($admin) {
            $_SESSION['admin_login'] = true;
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_name'] = $admin['username'];
            header('Location: index.php');
            exit;
        } else {
            $error_msg = '账号或密码错误';
        }
    } catch (PDOException $e) {
        $error_msg = '系统错误：' . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>后台登录</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="login-box">
        <h1>诺辞企业微信防投诉系统V6.0</h1>
        
        <?php if ($error_msg): ?>
            <div class="alert alert-danger"><?php echo $error_msg; ?></div>
        <?php endif; ?>
        
        <form method="post">
            <div class="form-group">
                <label>管理员账号</label>
                <input type="text" name="username" class="form-control" required>
            </div>
            <div class="form-group">
                <label>管理员密码</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-block">登录</button>
        </form>
    </div>
</body>
</html>