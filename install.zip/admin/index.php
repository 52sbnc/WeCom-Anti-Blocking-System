<?php
session_start();
// 关键修复：引入公共函数文件（缺失导致generate_unique_code未定义）
require_once '../config.php';
require_once '../functions.php';

// 未登录则跳转
if (!isset($_SESSION['admin_login']) || $_SESSION['admin_login'] !== true) {
    header('Location: login.php');
    exit;
}

$success_msg = '';
$error_msg = '';

// 处理添加/编辑
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $wechat_key = trim($_POST['wechat_key']);
    $email = trim($_POST['email']);
    $status = isset($_POST['status']) ? intval($_POST['status']) : 1;
    
    try {
        if ($id > 0) {
            // 编辑
            $stmt = $pdo->prepare("
                UPDATE complaint_links 
                SET wechat_key = ?, email = ?, status = ?, update_time = NOW() 
                WHERE id = ?
            ");
            $stmt->execute([$wechat_key, $email, $status, $id]);
            $success_msg = '链接编辑成功';
        } else {
            // 添加
            $unique_code = generate_unique_code();
            $stmt = $pdo->prepare("
                INSERT INTO complaint_links (unique_code, wechat_key, email, status) 
                VALUES (?, ?, ?, ?)
            ");
            $stmt->execute([$unique_code, $wechat_key, $email, $status]);
            $success_msg = '链接添加成功，唯一码：' . $unique_code;
        }
    } catch (PDOException $e) {
        $error_msg = '操作失败：' . $e->getMessage();
    }
}

// 处理停用/启用
if (isset($_GET['action']) && isset($_GET['id']) && intval($_GET['id']) > 0) {
    $id = intval($_GET['id']);
    $action = trim($_GET['action']);
    
    try {
        $status = $action === 'disable' ? 0 : 1;
        $stmt = $pdo->prepare("UPDATE complaint_links SET status = ? WHERE id = ?");
        $stmt->execute([$status, $id]);
        $success_msg = $action === 'disable' ? '链接已停用' : '链接已启用';
    } catch (PDOException $e) {
        $error_msg = '操作失败：' . $e->getMessage();
    }
}

// 获取链接列表
try {
    $stmt = $pdo->prepare("SELECT * FROM complaint_links ORDER BY id DESC");
    $stmt->execute();
    $links = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error_msg = '获取列表失败：' . $e->getMessage();
    $links = [];
}

// 获取编辑的链接信息
$edit_link = [];
if (isset($_GET['edit']) && intval($_GET['edit']) > 0) {
    $edit_id = intval($_GET['edit']);
    try {
        $stmt = $pdo->prepare("SELECT * FROM complaint_links WHERE id = ?");
        $stmt->execute([$edit_id]);
        $edit_link = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $error_msg = '获取编辑数据失败：' . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>投诉链接管理 - 后台</title>
    <link rel="stylesheet" href="assets/style.css">
    <script src="assets/script.js"></script>
</head>
<body>
    <div class="header">
        <h2>诺辞企业微信防投诉系统V6.0后台</h2>
        <div class="user-info">
            欢迎，<?php echo $_SESSION['admin_name']; ?> | 
            <a href="edit_admin.php">修改密码</a> | 
            <a href="login.php?action=logout" onclick="return confirm('确定退出？')">退出登录</a>
        </div>
    </div>
    
    <div class="container">
        <?php if ($success_msg): ?>
            <div class="alert alert-success"><?php echo $success_msg; ?></div>
        <?php endif; ?>
        
        <?php if ($error_msg): ?>
            <div class="alert alert-danger"><?php echo $error_msg; ?></div>
        <?php endif; ?>
        
        <!-- 添加/编辑链接表单 -->
        <div class="card">
            <div class="card-header">
                <h3><?php echo $edit_link ? '编辑投诉链接' : '添加投诉链接'; ?></h3>
            </div>
            <form method="post">
                <input type="hidden" name="id" value="<?php echo $edit_link['id'] ?? 0; ?>">
                <div class="form-group">
                    <label>企业微信机器人Key</label>
                    <input type="text" name="wechat_key" class="form-control" 
                           value="<?php echo $edit_link['wechat_key'] ?? ''; ?>" 
                           placeholder="填写企业微信机器人Key，为空则不推送微信通知">
                </div>
                <div class="form-group">
                    <label>收件邮箱</label>
                    <input type="email" name="email" class="form-control" 
                           value="<?php echo $edit_link['email'] ?? ''; ?>" 
                           placeholder="填写收件邮箱，为空则不发送邮件通知">
                </div>
                <div class="form-group">
                    <label>状态</label>
                    <select name="status" class="form-control">
                        <option value="1" <?php echo ($edit_link['status'] ?? 1) == 1 ? 'selected' : ''; ?>>启用</option>
                        <option value="0" <?php echo ($edit_link['status'] ?? 1) == 0 ? 'selected' : ''; ?>>停用</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-success">
                    <?php echo $edit_link ? '保存修改' : '添加链接'; ?>
                </button>
                <?php if ($edit_link): ?>
                    <a href="index.php" class="btn btn-outline" style="margin-left:10px;">取消</a>
                <?php endif; ?>
            </form>
        </div>
        
        <!-- 链接列表 -->
        <div class="card">
            <div class="card-header">
                <h3>投诉链接列表</h3>
                <a href="complaint_list.php" class="btn btn-outline">查看投诉记录</a>
            </div>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>唯一码</th>
                        <th>投诉链接1</th>
                        <th>投诉链接2</th>
                        <th>投诉链接3</th>
                        <th>微信Key</th>
                        <th>收件邮箱</th>
                        <th>状态</th>
                        <th>创建时间</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($links)): ?>
                        <tr>
                            <td colspan="8" style="text-align:center;">暂无链接数据</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($links as $link): ?>
                            <tr>
                                <td><?php echo $link['id']; ?></td>
                                <td><?php echo $link['unique_code']; ?></td>
                                <td>
                                    <?php 
                                    $complaint_url = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']) . '/../ts1.php?code=' . $link['unique_code'];
                                    ?>
                                    <a href="<?php echo $complaint_url; ?>" target="_blank">点击访问</a>
                                </td>
                                 <td>
                                    <?php 
                                    $complaint_url = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']) . '/../ts2.php?code=' . $link['unique_code'];
                                    ?>
                                    <a href="<?php echo $complaint_url; ?>" target="_blank">点击访问</a>
                                </td>
                                 <td>
                                    <?php 
                                    $complaint_url = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']) . '/../ts3.php?code=' . $link['unique_code'];
                                    ?>
                                    <a href="<?php echo $complaint_url; ?>" target="_blank">点击访问</a>
                                </td>
                                <td><?php echo $link['wechat_key'] ?: '未设置'; ?></td>
                                <td><?php echo $link['email'] ?: '未设置'; ?></td>
                                <td><?php echo $link['status'] ? '<span style="color:green;">启用</span>' : '<span style="color:red;">停用</span>'; ?></td>
                                <td><?php echo $link['create_time']; ?></td>
                                <td>
                                    <a href="index.php?edit=<?php echo $link['id']; ?>" class="btn btn-outline" style="padding:5px 10px;font-size:12px;">编辑</a>
                                    <?php if ($link['status']): ?>
                                        <a href="index.php?action=disable&id=<?php echo $link['id']; ?>" onclick="confirmDelete(this.href);return false;" class="btn btn-danger" style="padding:5px 10px;font-size:12px;margin-left:5px;">停用</a>
                                    <?php else: ?>
                                        <a href="index.php?action=enable&id=<?php echo $link['id']; ?>" class="btn btn-success" style="padding:5px 10px;font-size:12px;margin-left:5px;">启用</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>