<?php
session_start();
require_once '../config.php';
require_once '../functions.php'; 
// 未登录则跳转
if (!isset($_SESSION['admin_login']) || $_SESSION['admin_login'] !== true) {
    header('Location: login.php');
    exit;
}

// 获取链接列表（用于筛选）
try {
    $link_stmt = $pdo->prepare("SELECT id, unique_code FROM complaint_links ORDER BY id DESC");
    $link_stmt->execute();
    $all_links = $link_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $all_links = [];
    $error_msg = '获取链接列表失败：' . $e->getMessage();
}

// 筛选条件
$link_id = isset($_GET['link_id']) ? intval($_GET['link_id']) : 0;
$where = '';
$params = [];
if ($link_id > 0) {
    $where = "WHERE cr.link_id = ?";
    $params[] = $link_id;
}

// 获取投诉记录
try {
    $stmt = $pdo->prepare("
        SELECT cr.*, cl.unique_code 
        FROM complaint_records cr
        LEFT JOIN complaint_links cl ON cr.link_id = cl.id
        {$where}
        ORDER BY cr.id DESC
    ");
    $stmt->execute($params);
    $complaints = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error_msg = '获取投诉记录失败：' . $e->getMessage();
    $complaints = [];
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>投诉记录 - 后台</title>
    <link rel="stylesheet" href="assets/style.css">
    <script src="assets/script.js"></script>
</head>
<body>
    <div class="header">
        <h2>投诉系统后台</h2>
        <div class="user-info">
            欢迎，<?php echo $_SESSION['admin_name']; ?> | 
            <a href="edit_admin.php">修改密码</a> | 
            <a href="login.php?action=logout" onclick="return confirm('确定退出？')">退出登录</a>
        </div>
    </div>
    
    <div class="container">
        <?php if (isset($error_msg)): ?>
            <div class="alert alert-danger"><?php echo $error_msg; ?></div>
        <?php endif; ?>
        
        <!-- 筛选表单 -->
        <div class="card">
            <div class="card-header">
                <h3>投诉记录筛选</h3>
                <a href="index.php" class="btn btn-outline">返回链接管理</a>
            </div>
            <form onsubmit="filterComplaints();return false;">
                <div class="form-group">
                    <label>按投诉链接筛选</label>
                    <select id="link_id" class="form-control">
                        <option value="0">全部链接</option>
                        <?php foreach ($all_links as $link): ?>
                            <option value="<?php echo $link['id']; ?>" <?php echo $link_id == $link['id'] ? 'selected' : ''; ?>>
                                链接ID:<?php echo $link['id']; ?> (码:<?php echo $link['unique_code']; ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" class="btn">筛选</button>
            </form>
        </div>
        
        <!-- 投诉记录列表 -->
        <div class="card">
            <div class="card-header">
                <h3>投诉记录列表（共<?php echo count($complaints); ?>条）</h3>
            </div>
            <table class="table">
                <thead>
                    <tr>
                        <th>投诉ID</th>
                        <th>关联链接码</th>
                        <th>投诉类型</th>
                        <th>联系方式</th>
                        <th>图片数</th>
                        <th>提交IP</th>
                        <th>提交时间</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($complaints)): ?>
                        <tr>
                            <td colspan="8" style="text-align:center;">暂无投诉记录</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($complaints as $item): ?>
                            <tr>
                                <td><?php echo $item['id']; ?></td>
                                <td><?php echo $item['unique_code']; ?></td>
                                <td><?php echo $item['type']; ?></td>
                                <td><?php echo $item['contact'] ?: '无'; ?></td>
                                <td><?php echo $item['images'] ? count(explode(',', $item['images'])) : 0; ?></td>
                                <td><?php echo $item['ip']; ?></td>
                                <td><?php echo $item['submit_time']; ?></td>
                                <td>
                                    <button class="btn btn-outline" style="padding:5px 10px;font-size:12px;" onclick="viewComplaint(<?php echo $item['id']; ?>)">查看详情</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- 投诉详情弹窗（隐藏） -->
    <div id="complaintModal" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.8);z-index:9999;justify-content:center;align-items:center;">
        <div id="modalContent" style="background:#fff;padding:20px;border-radius:8px;max-width:800px;width:90%;max-height:80vh;overflow:auto;">
            <span onclick="document.getElementById('complaintModal').style.display='none'" style="float:right;cursor:pointer;font-size:20px;">&times;</span>
            <div id="complaintDetail"></div>
        </div>
    </div>

    <script>
    // 查看投诉详情
    function viewComplaint(id) {
        fetch('view_complaint.php?id=' + id)
            .then(response => response.text())
            .then(html => {
                document.getElementById('complaintDetail').innerHTML = html;
                document.getElementById('complaintModal').style.display = 'flex';
            })
            .catch(error => alert('获取详情失败：' + error));
    }
    </script>
</body>
</html>