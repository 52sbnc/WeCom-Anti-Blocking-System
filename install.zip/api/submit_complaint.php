<?php
require_once '../functions.php';

$response = ['success' => false, 'message' => ''];

try {
    // 获取参数
    $link_code = isset($_POST['link_code']) ? trim($_POST['link_code']) : '';
    $type = isset($_POST['type']) ? trim($_POST['type']) : '';
    $content = isset($_POST['content']) ? trim($_POST['content']) : '';
    $contact = isset($_POST['contact']) ? trim($_POST['contact']) : '';
    $ip = get_client_ip();
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    // 验证参数
    if (empty($link_code) || empty($type) || empty($content)) {
        throw new Exception('参数不完整');
    }
    
    // 获取投诉链接信息
    $stmt = $pdo->prepare("SELECT * FROM complaint_links WHERE unique_code = ? AND status = 1");
    $stmt->execute([$link_code]);
    $link = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$link) {
        throw new Exception('投诉链接无效');
    }
    
    // 处理图片上传
    $image_urls = [];
    if (!empty($_FILES['images']['name'][0])) {
        foreach ($_FILES['images']['tmp_name'] as $key => $tmp_name) {
            $file = [
                'name' => $_FILES['images']['name'][$key],
                'tmp_name' => $tmp_name,
                'size' => $_FILES['images']['size'][$key],
                'type' => $_FILES['images']['type'][$key]
            ];
            
            if (!secure_upload($file)) continue;
            
            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            $new_name = md5($link_code . time() . $key) . '.' . $ext;
            $save_path = UPLOAD_PATH . $new_name;
            
            if (move_uploaded_file($tmp_name, $save_path)) {
                $image_urls[] = UPLOAD_URL . $new_name;
            }
        }
    }
    
    // 保存投诉记录
    $stmt = $pdo->prepare("
        INSERT INTO complaint_records 
        (link_id, type, content, contact, images, ip, user_agent) 
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $link['id'],
        $type,
        $content,
        $contact,
        implode(',', $image_urls),
        $ip,
        $user_agent
    ]);
    
    $complaint_id = $pdo->lastInsertId();
    if (!$complaint_id) {
        throw new Exception('保存投诉记录失败');
    }
    
    // 异步发送通知
    send_wechat_notify(
        $link['wechat_key'],
        $complaint_id,
        $type,
        $content,
        $contact,
        $ip,
        count($image_urls)
    );
    
    send_email_notify(
        $link['email'],
        $complaint_id,
        $type,
        $content,
        $contact,
        $ip,
        count($image_urls)
    );
    
    $response = ['success' => true, 'message' => '提交成功'];
    
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
    error_log('投诉提交失败：' . $e->getMessage());
}

header('Content-Type: application/json');
echo json_encode($response, JSON_UNESCAPED_UNICODE);
?>